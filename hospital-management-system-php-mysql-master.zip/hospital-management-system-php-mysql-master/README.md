# Hospital Management System Mini-Project

This **was my first short PHP project** for Web Technology subject created in October 2016. 

## Features:
  1. Front Page Slideshow
  2. Login / Logout for customer.
  3. Seperate login for admin (location/hms-admin) - username: admin, password: admin
  4. Navigation Bar
  5. Ability to Add patient detail and book appointment.
  6. CSS using Twitter Bootstrap
  
  
